const AWS = require('aws-sdk');
const S3 = new AWS.S3({
  signatureVersion: 'v4',
});
const Sharp = require('sharp');

exports.handler = function (event, context, callback) {
    'use strict';
    console.log('processing', JSON.stringify(event));
    var eventRecord = event.Records && event.Records[0];
    if (eventRecord) {
        if (eventRecord.eventSource === 'aws:s3' && eventRecord.s3) {
            let crops = [{
                folder: 'thumbnails/300x300',
                width: 300,
                height: 300,
                contentType: 'image/jpeg',
                format: 'jpg'
            },
            {
                folder: 'thumbnails/100x100',
                width: 100,
                height: 100,
                contentType: 'image/jpeg',
                format: 'jpg'
            }]

            let bucket = eventRecord.s3.bucket.name
            let fileKey = eventRecord.s3.object.key

            S3.getObject({Bucket: bucket, Key: fileKey}).promise()
                .then(
                    file => Promise.all(crops.map(_crop => {
                        return Sharp(file.Body)
                        .resize(_crop.width, _crop.height)
                        .toFormat(_crop.format)
                        .toBuffer()
                        .then(_buffer => {
                            return { 
                                config: _crop,
                                buffer: _buffer
                            }
                        })
                    }))
                )
                .then(_croppedFiles => {
                    return Promise.all(_croppedFiles.map(_cropFile => {
                        return  S3.putObject({
                            Body: _cropFile.buffer,
                            Bucket: bucket,
                            ContentType: _cropFile.config.contentType,
                            Key: _cropFile.config.folder+fileKey
                          }).promise()                        
                    }))
                })
                .then(callback(null, {result: 'ok'}))
                .catch(err => callback(err))

        } else {
            callback('unsupported event source');
        }
    } else {
        callback('no records in the event');
    }
};

